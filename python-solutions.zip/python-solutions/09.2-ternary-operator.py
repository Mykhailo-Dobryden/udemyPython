my_str = "Very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very, very long string"

print("String is long" if len(my_str) > 79 else "String is short")
