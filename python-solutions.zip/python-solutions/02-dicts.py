my_dict = {}

key_1 = input("Please enter key 1: ")
value_1 = input("Please enter value 1: ")

my_dict[key_1] = value_1

key_2 = input("Please enter key 2: ")
value_2 = input("Please enter value 2: ")

my_dict[key_2] = value_2

key_3 = input("Please enter key 3: ")
value_3 = input("Please enter value 3: ")

my_dict[key_3] = value_3

print(my_dict)
