my_motorbike = ['BMW', 'Germany', 'Bogdan']

bike = [el for el in my_motorbike if len(el) > 3]

print(bike)
print(my_motorbike)
