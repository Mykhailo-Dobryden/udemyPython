set_one = {10, 5, 7, 15, 100}

set_one.add(200)

set_two = {20, 7, 300, 100, 200}

intersected_set = set_one.intersection(set_two)
print(intersected_set)

my_list = list(intersected_set)
print(my_list)

print(set_one)
print(set_two)
